<?php

$redirect = "http://pandoc.org/try/?text=&amp;from=latex&amp;to=html";
 
header("location:$redirect");

?>
