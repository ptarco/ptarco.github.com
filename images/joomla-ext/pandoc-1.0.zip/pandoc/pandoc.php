<?php

/**@version     $Id: pandoc.php 1 2015-04-27 14:20:00Z ptarcode $
  * @package     JSNUniform
  * @subpackage  Plugin
  * @author      Paulo de Tarço<ptarcode@gmail.com>
  * @license     GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
  * Websites: http://www.ptarcode.github.io
  * Technical Support:  <ptarcode@gmail.com>
 */

defined('_JEXEC') or die('Restricted access');

/**
 * Plugin button show pandoc window when edit content
 *
 * @package     Joomla.Plugin
 * 
 * @subpackage  Content.joomla
 * 
 * @since       2.6
 */
class plgButtonPandoc extends JPlugin
{

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param   object  &$subject  The object to observe
	 * 
	 * @param   array   $config    An array that holds the plugin configuration
	 * 
	 * @since 1.5
	 */
	public function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}

	/**
	 * Display the button
	 *
	 * @param   String  $name  Name button
	 *
	 * @return array A two element array of (imageName, textToInsert)
	 */
	function onDisplay($name)
	{
		$js   = "
		  function jsnSelectForm(id) {
				jInsertEditorText('{uniform form='+id+'/}', '" . $name . "');
				SqueezeBox.close();

		  }";
		$doc  = JFactory::getDocument();
		$doc->addScriptDeclaration($js);

		$link = '../plugins/editors-xtd/pandoc/redirect_pandoc.php';

		JHtml::_('behavior.modal');

		$button = new JObject;

		$button->set('modal', true);
		$button->set('link', $link);
		$button->set('text', JText::_('Pandoc'));
		$button->set('name', 'pagebreak');
		$button->set('options', "{handler: 'iframe', size: {x: 1000, y: 600}}");

		return $button;
	}
}
